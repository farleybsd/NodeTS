import App from './app';

App.app.listen(3000, () => console.log("SERVER RODANDO"));